package gui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import business.Bahnhof;
import business.BahnhofModel;
import javafx.stage.Stage;

public class BahnhoefeControl {
	
	private BahnhoefeView bahnhoefeView;
	private BahnhofModel bahnhofModel;
		
		
	public   BahnhoefeControl(Stage primaryStage) {
		
		this.bahnhofModel = new BahnhofModel();
		this.bahnhoefeView= new BahnhoefeView(primaryStage,bahnhofModel,this);
		
		
	}
	
	
	 public void nehmeBahnhofAuf(){
	    	try{ 
	    		this.bahnhofModel.setBahnhof(  new Bahnhof(
	    				bahnhoefeView.getTxtName().getText(), 
	    				bahnhoefeView.getTxtOrt().getText(),
	   	            Integer.parseInt(bahnhoefeView.getTxtAnzahlGleise().getText()),
	   	        	Integer.parseInt(bahnhoefeView.getTxtLetzteRenovierung().getText()),
	   	        	bahnhoefeView.getTxtZugarten().getText().split(";")));// ) 
	    		bahnhoefeView.zeigeInformationsfensterAn("Der Bahnhof wurde aufgenommen!");
	       	}
	       	catch(Exception exc){
	       		bahnhoefeView.zeigeFehlermeldungsfensterAn(exc.getMessage());
	     	}
	    }
	
	
	 public void leseAusDatei(String typ){
	    	try {
	    		if("csv".equals(typ)){
	    		
	    			bahnhofModel.leseAusDatei(typ);
	    		
	    		
	    			bahnhoefeView.zeigeInformationsfensterAn(
	      	  	   			"Der Bahnhof wurde gelesen!");
	    		}
	       		else{
	       			bahnhoefeView.zeigeInformationsfensterAn(
		   				"Noch nicht implementiert!");
		   		}
	    	}
			catch(IOException exc){
				bahnhoefeView.zeigeFehlermeldungsfensterAn(
					"IOException beim Lesen!");
			}
			catch(Exception exc){
				bahnhoefeView.zeigeFehlermeldungsfensterAn(
					"Unbekannter Fehler beim Lesen!");
			}
		}
			
		public void schreibeBahnhoefeInCsvDatei() {
			try {
				
				bahnhofModel.schreibeBahnhoefeInCsvDatei();
				
				bahnhoefeView.zeigeInformationsfensterAn(
		   			"Die Bahnhoefe wurden gespeichert!");
			}	
			catch(IOException exc){
				bahnhoefeView.zeigeFehlermeldungsfensterAn(
					"IOException beim Speichern!");
			}
			catch(Exception exc){
				bahnhoefeView.zeigeFehlermeldungsfensterAn(
					"Unbekannter Fehler beim Speichern!");
			}
		}

}
